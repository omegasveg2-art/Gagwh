#include "local_mem.h"
#include <csignal>
#include <csetjmp>
#include <cstdio>
#include <cstdlib>
#include <fstream>
#include <sstream>
#include <sys/mman.h>
#include <unistd.h>

// One jmp target per thread: OxGame's update() loop runs on a single worker thread in the injected build,
// but this keeps it correct if that ever changes.
static thread_local sigjmp_buf g_jmp;
static thread_local volatile sig_atomic_t g_guarded = 0;
static struct sigaction g_prevSegv{}, g_prevBus{};

static void fault_handler(int sig, siginfo_t* info, void* ctx) {
    if (g_guarded) {
        g_guarded = 0;
        siglongjmp(g_jmp, 1);
    }
    // not one of our guarded accesses -- this is a real crash, let the previous handler (or default) deal with it
    struct sigaction* prev = (sig == SIGSEGV) ? &g_prevSegv : &g_prevBus;
    if (prev->sa_flags & SA_SIGINFO) {
        if (prev->sa_sigaction) prev->sa_sigaction(sig, info, ctx);
        return;
    }
    if (prev->sa_handler == SIG_DFL) { signal(sig, SIG_DFL); raise(sig); return; }
    if (prev->sa_handler != SIG_IGN && prev->sa_handler) prev->sa_handler(sig);
}

void install_fault_guard() {
    struct sigaction sa{};
    sa.sa_sigaction = fault_handler;
    sa.sa_flags = SA_SIGINFO | SA_NODEFER;
    sigemptyset(&sa.sa_mask);
    sigaction(SIGSEGV, &sa, &g_prevSegv);
    sigaction(SIGBUS, &sa, &g_prevBus);
}

bool LocalMem::read(uint64_t addr, void* out, size_t n) {
    memset(out, 0, n);
    if (!addr) return false;
    g_guarded = 1;
    if (sigsetjmp(g_jmp, 1) != 0) { g_guarded = 0; return false; }   // longjmp landed here: the memcpy below faulted
    memcpy(out, (const void*)addr, n);
    g_guarded = 0;
    return true;
}

bool LocalMem::write(uint64_t addr, const void* in, size_t n) {
    if (!addr) return false;
    long pg = sysconf(_SC_PAGESIZE);
    uint64_t lo = addr & ~(uint64_t)(pg - 1);
    uint64_t hi = (addr + n + pg - 1) & ~(uint64_t)(pg - 1);
    if (mprotect((void*)lo, (size_t)(hi - lo), PROT_READ | PROT_WRITE | PROT_EXEC) != 0) return false;   // leave RWX: cave trampolines execute from here
    g_guarded = 1;
    if (sigsetjmp(g_jmp, 1) != 0) { g_guarded = 0; return false; }
    memcpy((void*)addr, in, n);
    g_guarded = 0;
    return true;
}

std::vector<Region> LocalMem::regions() {
    std::vector<Region> out;
    std::ifstream f("/proc/self/maps");
    std::string line;
    while (std::getline(f, line)) {
        uint64_t s = 0, e = 0;
        char rf = '-', wf = '-', xf = '-', pf = '-';
        uint64_t off = 0;
        unsigned dmaj = 0, dmin = 0;
        unsigned long ino = 0;
        int consumed = 0;
        if (sscanf(line.c_str(), "%llx-%llx %c%c%c%c %llx %x:%x %lu %n",
                   (unsigned long long*)&s, (unsigned long long*)&e, &rf, &wf, &xf, &pf,
                   (unsigned long long*)&off, &dmaj, &dmin, &ino, &consumed) < 10) continue;
        Region r;
        r.start = s; r.end = e; r.pgoff = off;
        r.r = rf == 'r'; r.w = wf == 'w'; r.x = xf == 'x';
        if (consumed > 0 && (size_t)consumed < line.size()) {
            size_t p = (size_t)consumed;
            while (p < line.size() && line[p] == ' ') p++;
            r.path = line.substr(p);
        }
        out.push_back(r);
    }
    return out;
}
