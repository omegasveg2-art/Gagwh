// Oxide: Survival Island (obfuscated build: re-dump + update after every game patch).
// Re-derived field-by-field from dump.csALABYBA (uploaded today, modified Oct 31 -- the actual current
// install, confirmed by file recency over every other dump sitting around). The previous edit in this file
// used dump_1.16.11978.zip by mistake (that's literally its filename) -- a stale, older dump whose
// PlayerManager layout predates the parachuteConfig field. ALABYBA's PlayerManager (TypeDefIndex: 10206)
// DOES have parachuteConfig at the front (0x68), which is the shift this file had originally, before that
// bad edit. Confirmed line by line again against dump.csALABYBA so this doesn't flip a third time blind.
#pragma once
#include <cstdint>

struct ClassRef { const char* ns; const char* name; uint64_t typeinfo_rva; };

namespace off {
namespace PlayerManager {            // class Oxide.PlayerManager : NetworkBehaviour
  constexpr ClassRef cls = {"Oxide", "PlayerManager", 0};
  constexpr uint32_t netIdentity = 0x40;          // NetworkBehaviour.<netIdentity>k__BackingField -- base class, unaffected
  constexpr uint32_t fpManager = 0xD0;            // public FPManager fpManager; // 0xD0
  constexpr uint32_t vitals = 0x108;              // public PlayerVitals vitals; // 0x108
  constexpr uint32_t s_clientPlayerList = 0x10;   // static List<PlayerManager>
  constexpr uint32_t s_activePlayerList = 0x8;
  constexpr uint32_t mouseLook = 0xB0;            // public MouseLook mouseLook; // 0xB0
  constexpr uint32_t lookAngle = 0x208;           // public float lookAngle; // 0x208
  constexpr uint32_t kccReference = 0xF0;         // InterfaceReference<ta> kccReference; // 0xF0 -- _component at +0x10
  constexpr uint32_t lastTickPosition = 0x228;    // public Vector3 lastTickPosition; // 0x228
  constexpr uint32_t lastSavedPosition = 0x234;   // public Vector3 lastSavedPosition; // 0x234
  constexpr uint32_t nicklabel = 0x170;           // public ZJ nicklabel; // 0x170
  // anti-cheat telemetry PlayerManager keeps on itself per client, confirmed in ALABYBA right after lastSavedPosition:
  //   public float violationLevel;          // 0x21C
  //   public float speedhackPauseTime;      // 0x220
  //   public float speedhackDistance;       // 0x224
  //   public HackType lastViolationType;    // 0x260 (int enum, 4 bytes)
  //   public float nextTerrainCheck;        // 0x264
  //   public bool respawning;               // 0x268
  //   public bool suspectedControl;         // 0x269
  // Zeroing these every tick doesn't move the player (that's the KCC/physics component through kccReference, a
  // separate native object we don't have write offsets into) -- it only resets what the LOCAL client has recorded
  // about its own movement deltas for these specific counters. Whether the server independently re-derives the
  // same numbers server-side (and flags regardless) is unconfirmed -- this is a client-side telemetry reset, not
  // a proven server-side bypass. Ship it, test it, report what actually happens on a flagged run.
  constexpr uint32_t violationLevel = 0x21C;
  constexpr uint32_t speedhackPauseTime = 0x220;
  constexpr uint32_t speedhackDistance = 0x224;
  constexpr uint32_t lastViolationType = 0x260;
  constexpr uint32_t nextTerrainCheck = 0x264;
  constexpr uint32_t respawning = 0x268;
  constexpr uint32_t suspectedControl = 0x269;
  constexpr uint32_t flyhackPauseTime = 0x250;
  constexpr uint32_t flyhackDistanceVertical = 0x254;
  constexpr uint32_t flyhackInAirSeconds = 0x258;
  constexpr uint32_t flyhackDistanceHorizontal = 0x25C;
}
namespace NetworkIdentity { constexpr uint32_t isLocalPlayer = 0x4A; }   // confirmed in ALABYBA: <isLocalPlayer>k__BackingField // 0x4A
namespace FPManager { constexpr ClassRef cls = {"Oxide", "FPManager", 0}; constexpr uint32_t m_WorldCamera = 0x20; }   // confirmed in ALABYBA: public Camera m_WorldCamera; // 0x20
namespace FPHitscan {
  constexpr ClassRef cls = {"Oxide", "FPHitscan", 0};
  // ALABYBA: exactly ONE private void X(Ray x) in FPHitscan -- "emP". No ambiguity this time, confirmed
  // by grepping the whole class body, not assumed from an older dump.
  constexpr const char* fireCandidates[] = {"emP"};
  constexpr int fireCandidateCount = 1;
  // Direct RVA for emP, from a SEPARATE deobfuscated dump (imguisource_bot bundle, same build: PlayerManager
  // TypeDefIndex 10206 and FPHitscan TypeDefIndex 9985 both match ALABYBA exactly). That dump resolves emP's real
  // name as "SetRay" (private void SetRay_emP(Ray arg0_x)), confirming it IS the fire-ray setter, and prints:
  //   // RVA: 0x6E4A464 Offset: 0x6E46464 VA: 0x6E4A464 Slot: 65535 (Obf: emP)
  // Use this directly (base_ + rva) instead of the Il2CppClass.methods table walk: the walk returns
  // none_readable in every live test, meaning il2::K_METHODS/K_MCOUNT/MI_* (il2cpp.h, generic runtime struct
  // layout, "Unity 2021.2+") are wrong for whatever il2cpp build this game actually ships -- not fixable without
  // a libil2cpp.so disassembly, which isn't available here. RVA bypasses that struct entirely, same trust model
  // already used for ClassRef::typeinfo_rva. NOT yet confirmed against the imguisource_bot dump's OWN script.json
  // (which disagreed by 0xAC0 for this exact method -- script.json is unreliable, the per-method RVA comment in
  // its dump.cs is what's used here). Breaks on the next game patch same as any RVA; re-derive from a fresh dump.
  constexpr uint64_t setRayRva = 0x6E4A464;
}
namespace GameModes {        // HyperHug.Games.Oxide.Features.GameModes.GameModes : NetworkBehaviour, TypeDefIndex 6789
  // from the imguisource_bot deobfuscated dump (same build as ALABYBA, confirmed via PlayerManager/FPHitscan
  // TypeDefIndex match). Obfuscated field name "yyn", offset 0x1F0, type ThirdPersonMode:
  //   private ThirdPersonMode field_ThirdPersonMode_0x1F0_yyn; // 0x1F0
  // with a public settable property on the same object: set_ThirdPersonMode_pbI(ThirdPersonMode).
  constexpr ClassRef cls = {"HyperHug.Games.Oxide.Features.GameModes", "GameModes", 0};
  constexpr uint32_t thirdPersonMode = 0x1F0;
  // The dump's own printed enum constants (Off/Allowed/Forced) all read "= 0" -- Il2CppDumper failing to resolve
  // them, not evidence they're really all 0. INFERRED from plain C# default enum numbering (no explicit "= N" on
  // any member means sequential from the declaration order shown: Off, Allowed, Forced): Off=0, Allowed=1,
  // Forced=2. Not independently confirmed. If writing 2 does nothing or breaks the camera, this inference is wrong.
  constexpr int32_t modeForced = 2;
}
namespace Vitals {                   // GenericVitals/kAg: Entity (kAH) at 0x68; kAH.Health (reactive float) 0x98, DisplayName 0x88
  constexpr uint32_t Entity = 0x68;
  constexpr uint32_t m_MaxHealth = 0x88;
  constexpr uint32_t E_DisplayName = 0x88;
  constexpr uint32_t E_Health = 0x98;
  constexpr uint32_t E_Velocity = 0xB0;
  // From the imguisource_bot dump: Oxide.PlayerVitals : EntityVitals (TypeDefIndex 9928) holds three
  // StatDepleter references -- same class, same namespace "Oxide", confirmed field block:
  //   private StatDepleter m_ThirstDepletion;  // 0x128
  //   private StatDepleter m_HungerDepletion;  // 0x130
  //   private StatDepleter m_OxygenDepletion;  // 0x138
  constexpr uint32_t thirstDepletion = 0x128;
  constexpr uint32_t hungerDepletion = 0x130;
  constexpr uint32_t oxygenDepletion = 0x138;
  // Same PlayerVitals block, plain inline floats this time (no StatDepleter indirection):
  //   private float m_Temperature;    // 0x144
  //   private float m_RadiationLevel; // 0x148
  //   private float m_RadiationPoison;// 0x14C
  constexpr uint32_t temperature = 0x144;
  constexpr uint32_t radiationLevel = 0x148;
  constexpr uint32_t radiationPoison = 0x14C;
}
namespace StatDepleter {   // Oxide.StatDepleter (TypeDefIndex 9927), same dump:
  constexpr uint32_t depletionRate = 0x10;   // private float m_DepletionRate; // 0x10 -- zero it, stat stops draining
}
}
